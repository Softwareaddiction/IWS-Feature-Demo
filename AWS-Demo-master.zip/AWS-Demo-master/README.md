# AWS Demo
Angular AMS solution

== Installation procedure == Internal use only:



//FULL INSTALL:
** install components in server**
npm install -g npm
npm install -g grunt-cli
npm install -g bower
npm install -g yo
npm install -g generator-angular
*in /html/server
npm init
npm install --save express
npm install --save mongoose 
npm install --save node-restful
npm install --save method-override
npm install --save body-parser
npm install --save lodash
npm install --save multer


**install client files **
*in/hmtl/Client
yo angular
bower install --save restangular

